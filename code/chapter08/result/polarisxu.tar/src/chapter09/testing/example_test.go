package testing_test

import (
	. "chapter09/testing"
	"fmt"
)

func ExampleFib() {
	fmt.Println(Fib(7))
	// Output: 13
}
